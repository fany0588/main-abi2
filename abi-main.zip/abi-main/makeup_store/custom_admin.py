from django.contrib.admin import AdminSite


class SuperuserAdminSite(AdminSite):
    """AdminSite que solo permite acceso a superusuarios.

    Esto evita que usuarios con `is_staff` pero no superusuarios accedan
    al panel admin.
    """

    def has_permission(self, request):
        return bool(request.user and request.user.is_active and request.user.is_superuser)


custom_admin_site = SuperuserAdminSite(name="superadmin")
