from django.contrib import admin
from .custom_admin import custom_admin_site

# Reemplazar la instancia de admin.site por la personalizada que solo
# permite superusuarios. Esto debe realizarse antes de que se registren
# los modelos en el admin (las importaciones de admin de las apps usan
# la instancia actual de admin.site).
admin.site = custom_admin_site
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('tienda.urls')),  # Incluye las URLs de tienda
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)