from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from django.utils.html import format_html
from django.utils import timezone
from .models import *

# ===== ADMIN INLINE =====

class PerfilUsuarioInline(admin.StackedInline):
    """Perfil de usuario inline en el admin de User"""
    model = PerfilUsuario
    can_delete = False
    verbose_name_plural = 'Perfil de Usuario'
    fk_name = 'usuario'


class ItemCarritoInline(admin.TabularInline):
    """Items del carrito inline"""
    model = ItemCarrito
    extra = 0
    readonly_fields = ['subtotal']
    fields = ['producto', 'cantidad', 'subtotal']
    
    def subtotal(self, obj):
        return f"${obj.subtotal}"
    subtotal.short_description = 'Subtotal'


class ItemPedidoInline(admin.TabularInline):
    """Items del pedido inline"""
    model = ItemPedido
    extra = 0
    readonly_fields = ['subtotal']
    fields = ['producto', 'cantidad', 'precio_unitario', 'subtotal']
    
    def subtotal(self, obj):
        return f"${obj.subtotal}"
    subtotal.short_description = 'Subtotal'


class CalificacionProductoInline(admin.TabularInline):
    """Calificaciones inline en producto"""
    model = CalificacionProducto
    extra = 0
    readonly_fields = ['usuario', 'puntuacion', 'fecha_creacion']
    fields = ['usuario', 'puntuacion', 'titulo', 'comentario', 'fecha_creacion']


class ItemListaDeseosInline(admin.TabularInline):
    """Items de lista de deseos inline"""
    model = ItemListaDeseos
    extra = 0
    fields = ['producto', 'prioridad', 'fecha_agregado']


# ===== MODEL ADMINS =====

@admin.register(CategoriaProducto)
class CategoriaProductoAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'cantidad_productos', 'activo', 'fecha_creacion']
    list_filter = ['activo', 'fecha_creacion']
    search_fields = ['nombre', 'descripcion']
    prepopulated_fields = {'nombre': ('nombre',)}
    actions = ['activar_categorias', 'desactivar_categorias']
    
    def cantidad_productos(self, obj):
        return obj.cantidad_productos
    cantidad_productos.short_description = 'Productos'
    
    @admin.action(description='Activar categorías seleccionadas')
    def activar_categorias(self, request, queryset):
        queryset.update(activo=True)
        self.message_user(request, f'{queryset.count()} categorías activadas.')
    
    @admin.action(description='Desactivar categorías seleccionadas')
    def desactivar_categorias(self, request, queryset):
        queryset.update(activo=False)
        self.message_user(request, f'{queryset.count()} categorías desactivadas.')


@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = [
        'nombre', 'marca', 'tipo', 'precio', 'stock_display', 
        'destacado', 'en_oferta', 'activo', 'fecha_creacion'
    ]
    list_filter = [
        'tipo', 'marca', 'destacado', 'en_oferta', 'activo', 
        'categoria', 'fecha_creacion'
    ]
    search_fields = ['nombre', 'descripcion', 'sku', 'marca']
    readonly_fields = ['sku', 'slug', 'promedio_calificaciones', 'cantidad_calificaciones']
    list_editable = ['destacado', 'en_oferta', 'activo']
    prepopulated_fields = {'slug': ('nombre', 'marca')}
    # REMOVER filter_horizontal o usar solo para campos ManyToMany
    # filter_horizontal = []  # Comenta o elimina esta línea si no tienes campos ManyToMany
    actions = [
        'activar_productos', 'desactivar_productos', 
        'marcar_destacados', 'marcar_oferta', 'actualizar_stock'
    ]
    inlines = [CalificacionProductoInline]
    fieldsets = (
        ('Información Básica', {
            'fields': ('nombre', 'descripcion', 'sku', 'slug', 'categoria', 'tipo', 'marca')
        }),
        ('Precios y Stock', {
            'fields': ('precio', 'precio_original', 'stock', 'stock_minimo')
        }),
        ('Imágenes', {
            'fields': ('imagen_principal', 'imagen_2', 'imagen_3', 'imagen_4')
        }),
        ('Características', {
            'fields': (
                'colores_disponibles', 'tono', 'cobertura', 'textura', 
                'duracion', 'ingredientes', 'tipo_piel'
            )
        }),
        ('Metadata', {
            'fields': ('destacado', 'nuevo', 'en_oferta', 'activo', 'meta_descripcion')
        }),
        ('Estadísticas', {
            'fields': ('promedio_calificaciones', 'cantidad_calificaciones'),
            'classes': ('collapse',)
        }),
    )

    def get_readonly_fields(self, request, obj=None):
        """Make `slug` and `sku` editable when creating a new object so
        `prepopulated_fields` can populate the slug and no KeyError occurs.
        Keep them readonly when editing existing objects.
        """
        ro = list(self.readonly_fields or [])
        if obj is None:
            # On add form, allow slug and sku to be editable so prepopulated_fields works
            for f in ('slug', 'sku'):
                if f in ro:
                    ro.remove(f)
        return ro
    
    def stock_display(self, obj):
        if obj.agotado:
            return format_html('<span style="color: red; font-weight: bold;">AGOTADO</span>')
        elif obj.bajo_stock:
            return format_html(f'<span style="color: orange; font-weight: bold;">{obj.stock} (BAJO)</span>')
        return obj.stock
    stock_display.short_description = 'Stock'
    
    @admin.action(description='Activar productos seleccionados')
    def activar_productos(self, request, queryset):
        queryset.update(activo=True)
        self.message_user(request, f'{queryset.count()} productos activados.')
    
    @admin.action(description='Desactivar productos seleccionados')
    def desactivar_productos(self, request, queryset):
        queryset.update(activo=False)
        self.message_user(request, f'{queryset.count()} productos desactivados.')
    
    @admin.action(description='Marcar como destacados')
    def marcar_destacados(self, request, queryset):
        queryset.update(destacado=True)
        self.message_user(request, f'{queryset.count()} productos marcados como destacados.')
    
    @admin.action(description='Marcar como oferta')
    def marcar_oferta(self, request, queryset):
        queryset.update(en_oferta=True)
        self.message_user(request, f'{queryset.count()} productos marcados como oferta.')
    
    @admin.action(description='Añadir 10 unidades al stock')
    def actualizar_stock(self, request, queryset):
        for producto in queryset:
            producto.stock += 10
            producto.save()
        self.message_user(request, f'Stock actualizado para {queryset.count()} productos.')


class UserAdmin(BaseUserAdmin):
    """User admin personalizado con perfil inline"""
    inlines = [PerfilUsuarioInline]
    list_display = [
        'username', 'email', 'first_name', 'last_name', 
        'is_staff', 'is_active', 'date_joined', 'pedidos_count'
    ]
    list_filter = ['is_staff', 'is_active', 'groups', 'date_joined']
    search_fields = ['username', 'email', 'first_name', 'last_name']
    actions = ['activar_usuarios', 'desactivar_usuarios']
    
    def pedidos_count(self, obj):
        return obj.pedidos.count()
    pedidos_count.short_description = 'Pedidos'
    
    @admin.action(description='Activar usuarios seleccionados')
    def activar_usuarios(self, request, queryset):
        queryset.update(is_active=True)
        self.message_user(request, f'{queryset.count()} usuarios activados.')
    
    @admin.action(description='Desactivar usuarios seleccionados')
    def desactivar_usuarios(self, request, queryset):
        queryset.update(is_active=False)
        self.message_user(request, f'{queryset.count()} usuarios desactivados.')


@admin.register(Carrito)
class CarritoAdmin(admin.ModelAdmin):
    list_display = ['usuario', 'total_items', 'subtotal', 'fecha_actualizacion']
    list_filter = ['fecha_creacion']
    search_fields = ['usuario__username', 'usuario__email']
    readonly_fields = ['total_items', 'subtotal', 'total']
    inlines = [ItemCarritoInline]
    
    def total_items(self, obj):
        return obj.total_items
    total_items.short_description = 'Items'
    
    def subtotal(self, obj):
        return f"${obj.subtotal}"
    subtotal.short_description = 'Subtotal'
    
    def total(self, obj):
        return f"${obj.total}"
    total.short_description = 'Total'


@admin.register(Pedido)
class PedidoAdmin(admin.ModelAdmin):
    list_display = [
        'numero_pedido', 'usuario', 'estado_display', 'total', 
        'fecha_pedido', 'pagado', 'color_estado_badge'
    ]
    list_filter = ['estado', 'metodo_pago', 'pagado', 'fecha_pedido']
    search_fields = ['numero_pedido', 'usuario__username', 'usuario__email']
    readonly_fields = [
        'numero_pedido', 'subtotal', 'total', 'fecha_pedido', 
        'numero_seguimiento', 'tiempo_transcurrido'
    ]
    list_editable = ['pagado']
    actions = ['marcar_como_enviado', 'marcar_como_entregado', 'marcar_como_pagado']
    inlines = [ItemPedidoInline]
    fieldsets = (
        ('Información del Pedido', {
            'fields': ('numero_pedido', 'usuario', 'estado', 'fecha_pedido')
        }),
        ('Información de Envío', {
            'fields': (
                'direccion_envio', 'ciudad_envio', 'codigo_postal_envio', 
                'telefono_envio', 'instrucciones_especiales'
            )
        }),
        ('Información de Pago', {
            'fields': ('metodo_pago', 'subtotal', 'costo_envio', 'descuento', 'total', 'pagado', 'fecha_pago')
        }),
        ('Seguimiento', {
            'fields': ('numero_seguimiento', 'empresa_envio', 'fecha_envio_estimada', 'fecha_envio_real')
        }),
        ('Metadata', {
            'fields': ('codigo_descuento', 'notas_internas'),
            'classes': ('collapse',)
        }),
    )
    
    def estado_display(self, obj):
        return obj.get_estado_display()
    estado_display.short_description = 'Estado'
    
    def color_estado_badge(self, obj):
        colors = {
            'pendiente': 'orange',
            'confirmado': 'blue',
            'procesando': 'purple',
            'enviado': 'green',
            'entregado': 'darkgreen',
            'cancelado': 'red',
            'reembolsado': 'gray',
        }
        color = colors.get(obj.estado, 'gray')
        return format_html(
            '<span style="background-color: {}; color: white; padding: 3px 8px; border-radius: 12px; font-weight: bold;">{}</span>',
            color, obj.get_estado_display()
        )
    color_estado_badge.short_description = 'Estado'
    
    def tiempo_transcurrido(self, obj):
        return f"{obj.tiempo_transcurrido} días"
    tiempo_transcurrido.short_description = 'Días desde pedido'
    
    @admin.action(description='Marcar como enviado')
    def marcar_como_enviado(self, request, queryset):
        queryset.update(estado='enviado', fecha_envio_real=timezone.now())
        self.message_user(request, f'{queryset.count()} pedidos marcados como enviados.')
    
    @admin.action(description='Marcar como entregado')
    def marcar_como_entregado(self, request, queryset):
        queryset.update(estado='entregado')
        self.message_user(request, f'{queryset.count()} pedidos marcados como entregados.')
    
    @admin.action(description='Marcar como pagado')
    def marcar_como_pagado(self, request, queryset):
        queryset.update(pagado=True, fecha_pago=timezone.now())
        self.message_user(request, f'{queryset.count()} pedidos marcados como pagado.')


@admin.register(CalificacionProducto)
class CalificacionProductoAdmin(admin.ModelAdmin):
    # CORREGIDO: Agregar 'activo' a list_display
    list_display = ['producto', 'usuario', 'puntuacion_stars', 'titulo', 'verificado_compra', 'activo', 'fecha_creacion']
    list_filter = ['puntuacion', 'verificado_compra', 'activo', 'fecha_creacion']
    search_fields = ['producto__nombre', 'usuario__username', 'titulo', 'comentario']
    # CORREGIDO: Solo 'verificado_compra' es editable, 'activo' ya está en list_display
    list_editable = ['verificado_compra']
    readonly_fields = ['fecha_creacion', 'fecha_actualizacion']
    actions = ['aprobar_calificaciones', 'rechazar_calificaciones']
    
    def puntuacion_stars(self, obj):
        return '★' * obj.puntuacion + '☆' * (5 - obj.puntuacion)
    puntuacion_stars.short_description = 'Puntuación'
    
    @admin.action(description='Aprobar calificaciones seleccionadas')
    def aprobar_calificaciones(self, request, queryset):
        queryset.update(activo=True)
        self.message_user(request, f'{queryset.count()} calificaciones aprobadas.')
    
    @admin.action(description='Rechazar calificaciones seleccionadas')
    def rechazar_calificaciones(self, request, queryset):
        queryset.update(activo=False)
        self.message_user(request, f'{queryset.count()} calificaciones rechazadas.')


@admin.register(Favorito)
class FavoritoAdmin(admin.ModelAdmin):
    list_display = ['usuario', 'producto', 'fecha_agregado']
    list_filter = ['fecha_agregado']
    search_fields = ['usuario__username', 'producto__nombre']
    date_hierarchy = 'fecha_agregado'


@admin.register(ListaDeseos)
class ListaDeseosAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'usuario', 'cantidad_items', 'publica', 'fecha_creacion']
    list_filter = ['publica', 'fecha_creacion']
    search_fields = ['nombre', 'usuario__username', 'descripcion']
    inlines = [ItemListaDeseosInline]
    
    def cantidad_items(self, obj):
        return obj.items.count()
    cantidad_items.short_description = 'Items'


@admin.register(CuponDescuento)
class CuponDescuentoAdmin(admin.ModelAdmin):
    list_display = [
        'codigo', 'tipo_descuento', 'valor', 'valido', 
        'usos_actuales', 'fecha_inicio', 'fecha_fin', 'activo'
    ]
    list_filter = ['tipo_descuento', 'activo', 'solo_nuevos_usuarios', 'fecha_inicio']
    search_fields = ['codigo', 'descripcion']
    # CORREGIDO: Solo usar filter_horizontal para campos ManyToMany
    filter_horizontal = ['productos_aplicables', 'categorias_aplicables']
    readonly_fields = ['usos_actuales']
    actions = ['activar_cupones', 'desactivar_cupones']
    
    def valido(self, obj):
        return obj.valido
    valido.boolean = True
    valido.short_description = 'Válido'


@admin.register(ArticuloBlog)
class ArticuloBlogAdmin(admin.ModelAdmin):
    list_display = ['titulo', 'autor', 'categoria', 'publicado', 'fecha_publicacion', 'vistas']
    list_filter = ['publicado', 'categoria', 'fecha_publicacion']
    search_fields = ['titulo', 'contenido', 'autor__username']
    prepopulated_fields = {'slug': ('titulo',)}
    readonly_fields = ['vistas', 'fecha_creacion']
    list_editable = ['publicado']
    date_hierarchy = 'fecha_publicacion'
    actions = ['publicar_articulos', 'ocultar_articulos']
    
    @admin.action(description='Publicar artículos seleccionados')
    def publicar_articulos(self, request, queryset):
        queryset.update(publicado=True, fecha_publicacion=timezone.now())
        self.message_user(request, f'{queryset.count()} artículos publicados.')
    
    @admin.action(description='Ocultar artículos seleccionados')
    def ocultar_articulos(self, request, queryset):
        queryset.update(publicado=False)
        self.message_user(request, f'{queryset.count()} artículos ocultados.')


@admin.register(ComentarioBlog)
class ComentarioBlogAdmin(admin.ModelAdmin):
    list_display = ['usuario', 'articulo', 'contenido_preview', 'aprobado', 'fecha_creacion']
    list_filter = ['aprobado', 'fecha_creacion']
    search_fields = ['usuario__username', 'articulo__titulo', 'contenido']
    list_editable = ['aprobado']
    actions = ['aprobar_comentarios', 'rechazar_comentarios']
    
    def contenido_preview(self, obj):
        return obj.contenido[:50] + '...' if len(obj.contenido) > 50 else obj.contenido
    contenido_preview.short_description = 'Comentario'
    
    @admin.action(description='Aprobar comentarios seleccionados')
    def aprobar_comentarios(self, request, queryset):
        queryset.update(aprobado=True)
        self.message_user(request, f'{queryset.count()} comentarios aprobados.')
    
    @admin.action(description='Rechazar comentarios seleccionados')
    def rechazar_comentarios(self, request, queryset):
        queryset.update(aprobado=False)
        self.message_user(request, f'{queryset.count()} comentarios rechazados.')


@admin.register(VisitaProducto)
class VisitaProductoAdmin(admin.ModelAdmin):
    list_display = ['producto', 'usuario', 'direccion_ip', 'fecha_visita']
    list_filter = ['fecha_visita']
    search_fields = ['producto__nombre', 'usuario__username', 'direccion_ip']
    date_hierarchy = 'fecha_visita'
    readonly_fields = ['fecha_visita']


@admin.register(BusquedaUsuario)
class BusquedaUsuarioAdmin(admin.ModelAdmin):
    list_display = ['query', 'usuario', 'resultados', 'fecha_busqueda']
    list_filter = ['fecha_busqueda']
    search_fields = ['query', 'usuario__username']
    date_hierarchy = 'fecha_busqueda'
    readonly_fields = ['fecha_busqueda']


# ===== REGISTRO Y CONFIGURACIÓN =====

# Re-registrar UserAdmin
admin.site.unregister(User)
admin.site.register(User, UserAdmin)


# Asegurar que la instancia personalizada `custom_admin_site` (si existe)
# también tenga registrados los mismos ModelAdmin. Esto es necesario cuando
# `admin.site` fue reemplazado después de que este módulo se importó.
try:
    from makeup_store.custom_admin import custom_admin_site

    _models_admin = [
        (CategoriaProducto, CategoriaProductoAdmin),
        (Producto, ProductoAdmin),
        (Carrito, CarritoAdmin),
        (Pedido, PedidoAdmin),
        (CalificacionProducto, CalificacionProductoAdmin),
        (Favorito, FavoritoAdmin),
        (ListaDeseos, ListaDeseosAdmin),
        (CuponDescuento, CuponDescuentoAdmin),
        (ArticuloBlog, ArticuloBlogAdmin),
        (ComentarioBlog, ComentarioBlogAdmin),
        (VisitaProducto, VisitaProductoAdmin),
        (BusquedaUsuario, BusquedaUsuarioAdmin),
    ]

    for _model, _admin in _models_admin:
        try:
            # Evitar doble registro provocando excepción
            if _model not in custom_admin_site._registry:
                custom_admin_site.register(_model, _admin)
        except Exception:
            # No bloquear el inicio por problemas de registro
            pass

    # Registrar User con la instancia personalizada también
    try:
        if User not in custom_admin_site._registry:
            custom_admin_site.register(User, UserAdmin)
    except Exception:
        pass
except Exception:
    # Si el módulo custom_admin no está disponible, no hacemos nada
    pass