from .models import Carrito

def carrito_count(request):
    """Añade el conteo del carrito al contexto"""
    if request.user.is_authenticated:
        try:
            carrito = Carrito.objects.get(usuario=request.user)
            count = carrito.items.count()
        except Carrito.DoesNotExist:
            count = 0
    else:
        count = 0
    
    return {'carrito_count': count}