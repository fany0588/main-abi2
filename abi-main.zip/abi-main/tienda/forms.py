from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import PerfilUsuario, Producto

class RegistroForm(UserCreationForm):
    email = forms.EmailField(required=True)
    telefono = forms.CharField(max_length=20, required=False)
    direccion = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}), required=False)
    
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']
    
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError('Este correo electrónico ya está registrado')
        return email

class UsuarioForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email']

class PerfilForm(forms.ModelForm):
    class Meta:
        model = PerfilUsuario
        fields = ['telefono', 'direccion', 'ciudad', 'codigo_postal', 'avatar']

class CheckoutForm(forms.ModelForm):
    metodo_pago = forms.ChoiceField(
        choices=[
            ('tarjeta', 'Tarjeta de Crédito/Débito'),
            ('paypal', 'PayPal'),
            ('transferencia', 'Transferencia Bancaria'),
        ],
        widget=forms.RadioSelect
    )
    
    class Meta:
        model = PerfilUsuario
        fields = ['telefono', 'direccion', 'ciudad', 'codigo_postal']
        widgets = {
            'direccion': forms.Textarea(attrs={'rows': 3}),
        }
    
    instrucciones_especiales = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 2}),
        required=False,
        label='Instrucciones especiales para la entrega'
    )

class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = '__all__'
        widgets = {
            'descripcion': forms.Textarea(attrs={'rows': 3}),
        }