from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.db.models import Q
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from .models import *
from .forms import *
import json

# ===== VISTAS PÚBLICAS =====

def index(request):
    """Página principal"""
    productos_destacados = Producto.objects.filter(destacado=True, activo=True)[:8]
    categorias = CategoriaProducto.objects.filter(activo=True)
    
    context = {
        'productos': productos_destacados,
        'categorias': categorias,
    }
    return render(request, 'index.html', context)

def productos_por_categoria(request, categoria_id):
    """Lista productos por categoría"""
    categoria = get_object_or_404(CategoriaProducto, id=categoria_id)
    productos = Producto.objects.filter(categoria=categoria, activo=True)
    
    context = {
        'categoria': categoria,
        'productos': productos,
    }
    return render(request, 'productos/categoria.html', context)

def producto_detalle(request, producto_id, slug=None):
    """Detalle de un producto específico"""
    producto = get_object_or_404(Producto, id=producto_id, activo=True)
    productos_relacionados = Producto.objects.filter(
        categoria=producto.categoria
    ).exclude(id=producto_id)[:4]
    
    context = {
        'producto': producto,
        'productos_relacionados': productos_relacionados,
    }
    return render(request, 'productos/detalle.html', context)

# ===== VISTAS DE AUTENTICACIÓN =====

def login_view(request):
    """Iniciar sesión"""
    if request.user.is_authenticated:
        return redirect('index')
    
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'¡Bienvenida de nuevo {user.first_name}!')
                
                # Redireccionar según el tipo de usuario
                if user.is_staff:
                    return redirect('admin_dashboard')
                else:
                    next_url = request.GET.get('next', 'index')
                    return redirect(next_url)
            else:
                messages.error(request, 'Usuario o contraseña incorrectos')
        else:
            messages.error(request, 'Por favor corrige los errores en el formulario')
    else:
        form = AuthenticationForm()
    
    return render(request, 'auth/login.html', {'form': form})

def registro_view(request):
    """Registro de nuevo usuario"""
    if request.user.is_authenticated:
        return redirect('index')
    
    if request.method == 'POST':
        form = RegistroForm(request.POST)
        if form.is_valid():
            user = form.save()
            
            # Crear perfil de usuario
            perfil = PerfilUsuario.objects.create(
                usuario=user,
                telefono=form.cleaned_data.get('telefono'),
                direccion=form.cleaned_data.get('direccion')
            )
            
            # Iniciar sesión automáticamente
            login(request, user)
            messages.success(request, '¡Cuenta creada exitosamente!')
            return redirect('index')
    else:
        form = RegistroForm()
    
    return render(request, 'auth/registro.html', {'form': form})

@login_required
def logout_view(request):
    """Cerrar sesión"""
    logout(request)
    messages.success(request, 'Has cerrado sesión exitosamente')
    return redirect('index')

# ===== VISTAS DE USUARIO =====

@login_required
def perfil(request):
    """Perfil del usuario"""
    perfil_usuario, created = PerfilUsuario.objects.get_or_create(usuario=request.user)
    
    if request.method == 'POST':
        user_form = UsuarioForm(request.POST, instance=request.user)
        perfil_form = PerfilForm(request.POST, instance=perfil_usuario)
        
        if user_form.is_valid() and perfil_form.is_valid():
            user_form.save()
            perfil_form.save()
            messages.success(request, 'Perfil actualizado exitosamente')
            return redirect('perfil')
    else:
        user_form = UsuarioForm(instance=request.user)
        perfil_form = PerfilForm(instance=perfil_usuario)
    
    # Obtener pedidos del usuario
    pedidos = Pedido.objects.filter(usuario=request.user).order_by('-fecha_pedido')
    
    context = {
        'user_form': user_form,
        'perfil_form': perfil_form,
        'pedidos': pedidos,
    }
    return render(request, 'usuario/perfil.html', context)

@login_required
def favoritos(request):
    """Lista de productos favoritos del usuario"""
    productos_favoritos = request.user.favoritos.all()
    
    context = {
        'favoritos': productos_favoritos,
    }
    return render(request, 'usuario/favoritos.html', context)

@login_required
@require_POST
def agregar_favorito(request, producto_id):
    """Agregar producto a favoritos (AJAX)"""
    producto = get_object_or_404(Producto, id=producto_id)
    
    if request.user.favoritos.filter(id=producto_id).exists():
        request.user.favoritos.remove(producto)
        favorito = False
        message = 'Producto eliminado de favoritos'
    else:
        request.user.favoritos.add(producto)
        favorito = True
        message = 'Producto agregado a favoritos'
    
    return JsonResponse({
        'success': True,
        'favorito': favorito,
        'message': message
    })

# ===== VISTAS DEL CARRITO =====

@login_required
def carrito(request):
    """Ver carrito de compras"""
    carrito, created = Carrito.objects.get_or_create(usuario=request.user)
    items = carrito.items.all()
    
    context = {
        'carrito': carrito,
        'items': items,
    }
    return render(request, 'carrito/carrito.html', context)

@login_required
@require_POST
def agregar_al_carrito(request, producto_id):
    """Agregar producto al carrito (AJAX)"""
    producto = get_object_or_404(Producto, id=producto_id)
    cantidad = int(request.POST.get('cantidad', 1))
    
    # Verificar stock disponible
    if producto.stock < cantidad:
        return JsonResponse({
            'success': False,
            'message': f'Solo quedan {producto.stock} unidades disponibles'
        })
    
    carrito, created = Carrito.objects.get_or_create(usuario=request.user)
    
    # Buscar si el producto ya está en el carrito
    item_carrito, item_created = ItemCarrito.objects.get_or_create(
        carrito=carrito,
        producto=producto
    )
    
    if not item_created:
        item_carrito.cantidad += cantidad
    else:
        item_carrito.cantidad = cantidad
    
    # Verificar que no exceda el stock
    if item_carrito.cantidad > producto.stock:
        item_carrito.cantidad = producto.stock
    
    item_carrito.save()
    
    # Actualizar contador del carrito
    carrito_count = carrito.items.count()
    
    return JsonResponse({
        'success': True,
        'message': 'Producto agregado al carrito',
        'cart_count': carrito_count,
        'subtotal': item_carrito.subtotal
    })

@login_required
@require_POST
def actualizar_carrito(request, item_id):
    """Actualizar cantidad de un producto en el carrito (AJAX)"""
    item = get_object_or_404(ItemCarrito, id=item_id, carrito__usuario=request.user)
    
    try:
        cantidad = int(request.POST.get('cantidad', 1))
    except ValueError:
        return JsonResponse({'success': False, 'message': 'Cantidad inválida'})
    
    # Verificar stock
    if cantidad > item.producto.stock:
        return JsonResponse({
            'success': False,
            'message': f'Solo quedan {item.producto.stock} unidades disponibles'
        })
    
    if cantidad <= 0:
        item.delete()
        eliminado = True
    else:
        item.cantidad = cantidad
        item.save()
        eliminado = False
    
    # Obtener carrito actualizado
    carrito = Carrito.objects.get(usuario=request.user)
    
    return JsonResponse({
        'success': True,
        'eliminado': eliminado,
        'subtotal': item.subtotal if not eliminado else 0,
        'total': carrito.total
    })

@login_required
@require_POST
def eliminar_del_carrito(request, item_id):
    """Eliminar producto del carrito (AJAX)"""
    item = get_object_or_404(ItemCarrito, id=item_id, carrito__usuario=request.user)
    item.delete()
    
    carrito = Carrito.objects.get(usuario=request.user)
    
    return JsonResponse({
        'success': True,
        'message': 'Producto eliminado del carrito',
        'total': carrito.total
    })

# ===== VISTAS DE CHECKOUT =====

@login_required
def checkout(request):
    """Proceso de pago"""
    carrito = get_object_or_404(Carrito, usuario=request.user)
    
    # Verificar que el carrito no esté vacío
    if carrito.items.count() == 0:
        messages.warning(request, 'Tu carrito está vacío')
        return redirect('carrito')
    
    # Verificar stock de todos los productos
    for item in carrito.items.all():
        if item.cantidad > item.producto.stock:
            messages.error(request, f'No hay suficiente stock de {item.producto.nombre}')
            return redirect('carrito')
    
    # Obtener o crear perfil del usuario
    perfil_usuario, created = PerfilUsuario.objects.get_or_create(usuario=request.user)
    
    if request.method == 'POST':
        form = CheckoutForm(request.POST, instance=perfil_usuario)
        
        if form.is_valid():
            # Crear pedido
            pedido = Pedido.objects.create(
                usuario=request.user,
                direccion_envio=form.cleaned_data['direccion'],
                ciudad_envio=form.cleaned_data['ciudad'],
                codigo_postal=form.cleaned_data['codigo_postal'],
                telefono=form.cleaned_data['telefono'],
                instrucciones_especiales=form.cleaned_data.get('instrucciones_especiales', ''),
                metodo_pago=form.cleaned_data['metodo_pago'],
                total=carrito.total
            )
            
            # Transferir items del carrito al pedido
            for item_carrito in carrito.items.all():
                ItemPedido.objects.create(
                    pedido=pedido,
                    producto=item_carrito.producto,
                    cantidad=item_carrito.cantidad,
                    precio_unitario=item_carrito.producto.precio
                )
                
                # Actualizar stock del producto
                producto = item_carrito.producto
                producto.stock -= item_carrito.cantidad
                producto.save()
            
            # Vaciar carrito
            carrito.items.all().delete()
            
            messages.success(request, '¡Pedido realizado exitosamente!')
            return redirect('confirmacion_pedido', pedido_id=pedido.id)
    else:
        form = CheckoutForm(instance=perfil_usuario)
    
    context = {
        'carrito': carrito,
        'form': form,
    }
    return render(request, 'checkout/checkout.html', context)

@login_required
def confirmacion_pedido(request, pedido_id):
    """Confirmación de pedido realizado"""
    pedido = get_object_or_404(Pedido, id=pedido_id, usuario=request.user)
    
    context = {
        'pedido': pedido,
    }
    return render(request, 'checkout/confirmacion.html', context)

@login_required
def historial_pedidos(request):
    """Historial de pedidos del usuario"""
    pedidos = Pedido.objects.filter(usuario=request.user).order_by('-fecha_pedido')
    
    context = {
        'pedidos': pedidos,
    }
    return render(request, 'usuario/pedidos.html', context)

@login_required
def detalle_pedido(request, pedido_id):
    """Detalle de un pedido específico"""
    pedido = get_object_or_404(Pedido, id=pedido_id, usuario=request.user)
    
    context = {
        'pedido': pedido,
    }
    return render(request, 'usuario/detalle_pedido.html', context)

# ===== VISTAS DE BÚSQUEDA =====

def buscar_productos(request):
    """Búsqueda de productos"""
    query = request.GET.get('q', '')
    
    if query:
        productos = Producto.objects.filter(
            Q(nombre__icontains=query) |
            Q(descripcion__icontains=query) |
            Q(marca__icontains=query)
        ).filter(activo=True)
    else:
        productos = Producto.objects.none()
    
    context = {
        'productos': productos,
        'query': query,
        'resultados_count': productos.count()
    }
    return render(request, 'productos/busqueda.html', context)


def ofertas(request):
    """Lista de productos que están en oferta"""
    productos = Producto.objects.filter(en_oferta=True, activo=True)
    context = {
        'productos': productos,
        'titulo': 'Ofertas'
    }
    return render(request, 'productos/ofertas.html', context)


def marcas(request):
    """Lista de marcas disponibles con contador de productos activos."""
    marcas = []
    for key, label in Producto.MARCA_CHOICES:
        count = Producto.objects.filter(marca=key, activo=True).count()
        marcas.append({'key': key, 'label': label, 'count': count})

    context = {
        'marcas': marcas,
        'titulo': 'Marcas'
    }
    return render(request, 'productos/marcas.html', context)


def productos_por_marca(request, marca_key):
    """Lista productos filtrados por marca (clave)."""
    # Obtener etiqueta legible
    label = dict(Producto.MARCA_CHOICES).get(marca_key, marca_key)
    productos = Producto.objects.filter(marca=marca_key, activo=True)

    context = {
        'productos': productos,
        'marca_key': marca_key,
        'marca_label': label,
    }
    return render(request, 'productos/marca.html', context)

# ===== VISTAS DE ADMINISTRACIÓN =====

from django.utils import timezone

@staff_member_required
def admin_dashboard(request):
    """Dashboard de administración"""
    from django.contrib.auth.models import User
    from .models import Producto, Pedido, CategoriaProducto
    
    # Estadísticas generales
    total_productos = Producto.objects.filter(activo=True).count()
    total_usuarios = User.objects.filter(is_active=True).count()
    pedidos_pendientes = Pedido.objects.filter(estado='pendiente').count()
    productos_bajo_stock = Producto.objects.filter(stock__lt=5, activo=True).count()
    
    # Últimos productos y pedidos
    ultimos_productos = Producto.objects.filter(activo=True).order_by('-fecha_creacion')[:5]
    ultimos_pedidos = Pedido.objects.all().order_by('-fecha_pedido')[:5]
    
    # Conteo por categorías (opcional)
    count_labiales = Producto.objects.filter(tipo='labial', activo=True).count()
    count_bases = Producto.objects.filter(tipo='base', activo=True).count()
    count_rimel = Producto.objects.filter(tipo='rimel', activo=True).count()
    count_rubores = Producto.objects.filter(tipo='rubor', activo=True).count()
    count_correctores = Producto.objects.filter(tipo='corrector', activo=True).count()
    count_polvos = Producto.objects.filter(tipo='polvo', activo=True).count()
    
    context = {
        'now': timezone.now(),
        'total_productos': total_productos,
        'total_usuarios': total_usuarios,
        'pedidos_pendientes': pedidos_pendientes,
        'productos_bajo_stock': productos_bajo_stock,
        'ultimos_productos': ultimos_productos,
        'ultimos_pedidos': ultimos_pedidos,
        'count_labiales': count_labiales,
        'count_bases': count_bases,
        'count_rimel': count_rimel,
        'count_rubores': count_rubores,
        'count_correctores': count_correctores,
        'count_polvos': count_polvos,
    }
    
    return render(request, 'admin/dashboard.html', context)



@staff_member_required
def gestion_categorias(request):
    categorias = CategoriaProducto.objects.all()
    return render(request, 'admin/productos/gestion_categorias.html', {
        'categorias': categorias
    })

@staff_member_required
def agregar_categoria(request):
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        descripcion = request.POST.get('descripcion')
        if nombre:
            CategoriaProducto.objects.create(
                nombre=nombre,
                descripcion=descripcion
            )
            messages.success(request, 'Categoría agregada exitosamente')
            return redirect('gestion_categorias')
    return redirect('gestion_categorias')

# ===== VISTAS DE PRODUCTOS (CRUD por categorías) =====

@staff_member_required
def listar_labiales(request):
    labiales = Producto.objects.filter(tipo='labial')
    return render(request, 'admin/productos/categorias/labiales/listar.html', {
        'productos': labiales,
        'categoria': 'Labiales'
    })

@staff_member_required
def agregar_labial(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES)
        if form.is_valid():
            producto = form.save(commit=False)
            producto.tipo = 'labial'
            producto.save()
            messages.success(request, 'Labial agregado exitosamente')
            return redirect('listar_labiales')
    else:
        form = ProductoForm(initial={'tipo': 'labial'})
    
    return render(request, 'admin/productos/categorias/labiales/agregar.html', {
        'form': form,
        'categoria': 'Labiales'
    })

@staff_member_required
def editar_labial(request, id):
    producto = get_object_or_404(Producto, id=id, tipo='labial')
    
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES, instance=producto)
        if form.is_valid():
            form.save()
            messages.success(request, 'Labial actualizado exitosamente')
            return redirect('listar_labiales')
    else:
        form = ProductoForm(instance=producto)
    
    return render(request, 'admin/productos/categorias/labiales/editar.html', {
        'form': form,
        'producto': producto,
        'categoria': 'Labiales'
    })

@staff_member_required
def eliminar_labial(request, id):
    producto = get_object_or_404(Producto, id=id, tipo='labial')
    
    if request.method == 'POST':
        producto.delete()
        messages.success(request, 'Labial eliminado exitosamente')
        return redirect('listar_labiales')
    
    return render(request, 'admin/productos/categorias/labiales/eliminar.html', {
        'producto': producto,
        'categoria': 'Labiales'
    })

@staff_member_required
def listar_bases(request):
    bases = Producto.objects.filter(tipo='base')
    return render(request, 'admin/productos/categorias/bases/listar.html', {
        'productos': bases,
        'categoria': 'Bases'
    })

@staff_member_required
def agregar_base(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES)
        if form.is_valid():
            producto = form.save(commit=False)
            producto.tipo = 'base'
            producto.save()
            messages.success(request, 'Base agregada exitosamente')
            return redirect('listar_bases')
    else:
        form = ProductoForm(initial={'tipo': 'base'})
    
    return render(request, 'admin/productos/categorias/bases/agregar.html', {
        'form': form,
        'categoria': 'Bases'
    })

@staff_member_required
def editar_base(request, id):
    producto = get_object_or_404(Producto, id=id, tipo='base')
    
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES, instance=producto)
        if form.is_valid():
            form.save()
            messages.success(request, 'Base actualizada exitosamente')
            return redirect('listar_bases')
    else:
        form = ProductoForm(instance=producto)
    
    return render(request, 'admin/productos/categorias/bases/editar.html', {
        'form': form,
        'producto': producto,
        'categoria': 'Bases'
    })

@staff_member_required
def eliminar_base(request, id):
    producto = get_object_or_404(Producto, id=id, tipo='base')
    
    if request.method == 'POST':
        producto.delete()
        messages.success(request, 'Base eliminada exitosamente')
        return redirect('listar_bases')
    
    return render(request, 'admin/productos/categorias/bases/eliminar.html', {
        'producto': producto,
        'categoria': 'Bases'
    })

@staff_member_required
def listar_rimel(request):
    rimel = Producto.objects.filter(tipo='rimel')
    return render(request, 'admin/productos/categorias/rimel/listar.html', {
        'productos': rimel,
        'categoria': 'Rímel'
    })

@staff_member_required
def agregar_rimel(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES)
        if form.is_valid():
            producto = form.save(commit=False)
            producto.tipo = 'rimel'
            producto.save()
            messages.success(request, 'Rímel agregado exitosamente')
            return redirect('listar_rimel')
    else:
        form = ProductoForm(initial={'tipo': 'rimel'})
    
    return render(request, 'admin/productos/categorias/rimel/agregar.html', {
        'form': form,
        'categoria': 'Rímel'
    })

@staff_member_required
def editar_rimel(request, id):
    producto = get_object_or_404(Producto, id=id, tipo='rimel')
    
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES, instance=producto)
        if form.is_valid():
            form.save()
            messages.success(request, 'Rímel actualizado exitosamente')
            return redirect('listar_rimel')
    else:
        form = ProductoForm(instance=producto)
    
    return render(request, 'admin/productos/categorias/rimel/editar.html', {
        'form': form,
        'producto': producto,
        'categoria': 'Rímel'
    })

@staff_member_required
def eliminar_rimel(request, id):
    producto = get_object_or_404(Producto, id=id, tipo='rimel')
    
    if request.method == 'POST':
        producto.delete()
        messages.success(request, 'Rímel eliminado exitosamente')
        return redirect('listar_rimel')
    
    return render(request, 'admin/productos/categorias/rimel/eliminar.html', {
        'producto': producto,
        'categoria': 'Rímel'
    })

@staff_member_required
def listar_rubores(request):
    rubores = Producto.objects.filter(tipo='rubor')
    return render(request, 'admin/productos/categorias/rubores/listar.html', {
        'productos': rubores,
        'categoria': 'Rubores'
    })

@staff_member_required
def agregar_rubor(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES)
        if form.is_valid():
            producto = form.save(commit=False)
            producto.tipo = 'rubor'
            producto.save()
            messages.success(request, 'Rubor agregado exitosamente')
            return redirect('listar_rubores')
    else:
        form = ProductoForm(initial={'tipo': 'rubor'})
    
    return render(request, 'admin/productos/categorias/rubores/agregar.html', {
        'form': form,
        'categoria': 'Rubores'
    })

@staff_member_required
def editar_rubor(request, id):
    producto = get_object_or_404(Producto, id=id, tipo='rubor')
    
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES, instance=producto)
        if form.is_valid():
            form.save()
            messages.success(request, 'Rubor actualizado exitosamente')
            return redirect('listar_rubores')
    else:
        form = ProductoForm(instance=producto)
    
    return render(request, 'admin/productos/categorias/rubores/editar.html', {
        'form': form,
        'producto': producto,
        'categoria': 'Rubores'
    })

@staff_member_required
def eliminar_rubor(request, id):
    producto = get_object_or_404(Producto, id=id, tipo='rubor')
    
    if request.method == 'POST':
        producto.delete()
        messages.success(request, 'Rubor eliminado exitosamente')
        return redirect('listar_rubores')
    
    return render(request, 'admin/productos/categorias/rubores/eliminar.html', {
        'producto': producto,
        'categoria': 'Rubores'
    })

@staff_member_required
def listar_correctores(request):
    correctores = Producto.objects.filter(tipo='corrector')
    return render(request, 'admin/productos/categorias/correctores/listar.html', {
        'productos': correctores,
        'categoria': 'Correctores'
    })

@staff_member_required
def agregar_corrector(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES)
        if form.is_valid():
            producto = form.save(commit=False)
            producto.tipo = 'corrector'
            producto.save()
            messages.success(request, 'Corrector agregado exitosamente')
            return redirect('listar_correctores')
    else:
        form = ProductoForm(initial={'tipo': 'corrector'})
    
    return render(request, 'admin/productos/categorias/correctores/agregar.html', {
        'form': form,
        'categoria': 'Correctores'
    })

@staff_member_required
def editar_corrector(request, id):
    producto = get_object_or_404(Producto, id=id, tipo='corrector')
    
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES, instance=producto)
        if form.is_valid():
            form.save()
            messages.success(request, 'Corrector actualizado exitosamente')
            return redirect('listar_correctores')
    else:
        form = ProductoForm(instance=producto)
    
    return render(request, 'admin/productos/categorias/correctores/editar.html', {
        'form': form,
        'producto': producto,
        'categoria': 'Correctores'
    })

@staff_member_required
def eliminar_corrector(request, id):
    producto = get_object_or_404(Producto, id=id, tipo='corrector')
    
    if request.method == 'POST':
        producto.delete()
        messages.success(request, 'Corrector eliminado exitosamente')
        return redirect('listar_correctores')
    
    return render(request, 'admin/productos/categorias/correctores/eliminar.html', {
        'producto': producto,
        'categoria': 'Correctores'
    })

@staff_member_required
def listar_polvos(request):
    polvos = Producto.objects.filter(tipo='polvo')
    return render(request, 'admin/productos/categorias/polvos/listar.html', {
        'productos': polvos,
        'categoria': 'Polvos'
    })

@staff_member_required
def agregar_polvo(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES)
        if form.is_valid():
            producto = form.save(commit=False)
            producto.tipo = 'polvo'
            producto.save()
            messages.success(request, 'Polvo agregado exitosamente')
            return redirect('listar_polvos')
    else:
        form = ProductoForm(initial={'tipo': 'polvo'})
    
    return render(request, 'admin/productos/categorias/polvos/agregar.html', {
        'form': form,
        'categoria': 'Polvos'
    })

@staff_member_required
def editar_polvo(request, id):
    producto = get_object_or_404(Producto, id=id, tipo='polvo')
    
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES, instance=producto)
        if form.is_valid():
            form.save()
            messages.success(request, 'Polvo actualizado exitosamente')
            return redirect('listar_polvos')
    else:
        form = ProductoForm(instance=producto)
    
    return render(request, 'admin/productos/categorias/polvos/editar.html', {
        'form': form,
        'producto': producto,
        'categoria': 'Polvos'
    })

@staff_member_required
def eliminar_polvo(request, id):
    producto = get_object_or_404(Producto, id=id, tipo='polvo')
    
    if request.method == 'POST':
        producto.delete()
        messages.success(request, 'Polvo eliminado exitosamente')
        return redirect('listar_polvos')
    
    return render(request, 'admin/productos/categorias/polvos/eliminar.html', {
        'producto': producto,
        'categoria': 'Polvos'
    })

@staff_member_required
def lista_productos_general(request):
    productos = Producto.objects.all().order_by('tipo', 'nombre')
    return render(request, 'admin/productos/lista_general.html', {
        'productos': productos
    })

# ===== VISTAS SIMPLIFICADAS TEMPORALES =====

# Para evitar errores, puedes crear vistas temporales simples
@staff_member_required
def gestion_usuarios(request):
    """Lista todos los usuarios - Vista temporal"""
    from django.contrib.auth.models import User
    usuarios = User.objects.all().order_by('-date_joined')
    return render(request, 'admin/usuarios/gestion.html', {'usuarios': usuarios})

@staff_member_required
def detalle_usuario(request, usuario_id):
    """Detalle de un usuario específico - Vista temporal"""
    from django.contrib.auth.models import User
    usuario = get_object_or_404(User, id=usuario_id)
    pedidos = Pedido.objects.filter(usuario=usuario).order_by('-fecha_pedido')
    
    return render(request, 'admin/usuarios/detalle.html', {
        'usuario': usuario,
        'pedidos': pedidos
    })

@staff_member_required
def gestion_pedidos(request):
    """Lista todos los pedidos - Vista temporal"""
    pedidos = Pedido.objects.all().order_by('-fecha_pedido')
    
    # Filtrar por estado si se especifica
    estado = request.GET.get('estado')
    if estado:
        pedidos = pedidos.filter(estado=estado)
    
    return render(request, 'admin/pedidos/gestion.html', {
        'pedidos': pedidos,
        'estado_filtro': estado
    })

@staff_member_required
def detalle_pedido_admin(request, pedido_id):
    """Detalle de un pedido para administración - Vista temporal"""
    pedido = get_object_or_404(Pedido, id=pedido_id)
    
    return render(request, 'admin/pedidos/detalle.html', {
        'pedido': pedido
    })