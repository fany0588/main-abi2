from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    # Páginas públicas
    path('', views.index, name='index'),
    path('categoria/<int:categoria_id>/', views.productos_por_categoria, name='productos_por_categoria'),
    path('producto/<int:producto_id>/<slug:slug>/', views.producto_detalle, name='producto_detalle'),
    path('producto/<int:producto_id>/', views.producto_detalle, name='producto_detalle_sin_slug'),
    path('buscar/', views.buscar_productos, name='buscar_productos'),
     path('ofertas/', views.ofertas, name='ofertas'),
     path('marcas/', views.marcas, name='marcas'),
     path('marca/<str:marca_key>/', views.productos_por_marca, name='productos_por_marca'),
    
    # Autenticación
    path('login/', views.login_view, name='login'),
    path('registro/', views.registro_view, name='registro'),
    path('logout/', views.logout_view, name='logout'),
    
    # Restablecimiento de contraseña
    path('password-reset/', 
         auth_views.PasswordResetView.as_view(template_name='tienda/auth/password_reset.html'),
         name='password_reset'),
    path('password-reset/done/', 
         auth_views.PasswordResetDoneView.as_view(template_name='tienda/auth/password_reset_done.html'),
         name='password_reset_done'),
    path('password-reset-confirm/<uidb64>/<token>/', 
         auth_views.PasswordResetConfirmView.as_view(template_name='tienda/auth/password_reset_confirm.html'),
         name='password_reset_confirm'),
    path('password-reset-complete/', 
         auth_views.PasswordResetCompleteView.as_view(template_name='tienda/auth/password_reset_complete.html'),
         name='password_reset_complete'),
    
    # Usuario
    path('perfil/', views.perfil, name='perfil'),
    path('favoritos/', views.favoritos, name='favoritos'),
    path('favoritos/agregar/<int:producto_id>/', views.agregar_favorito, name='agregar_favorito'),
    path('pedidos/', views.historial_pedidos, name='historial_pedidos'),
    path('pedido/<int:pedido_id>/', views.detalle_pedido, name='detalle_pedido'),
    
    # Carrito
    path('carrito/', views.carrito, name='carrito'),
    path('carrito/agregar/<int:producto_id>/', views.agregar_al_carrito, name='agregar_al_carrito'),
    path('carrito/actualizar/<int:item_id>/', views.actualizar_carrito, name='actualizar_carrito'),
    path('carrito/eliminar/<int:item_id>/', views.eliminar_del_carrito, name='eliminar_del_carrito'),
    
    # Checkout
    path('checkout/', views.checkout, name='checkout'),
    path('checkout/confirmacion/<int:pedido_id>/', views.confirmacion_pedido, name='confirmacion_pedido'),
    
    # Administración
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin-dashboard/categorias/', views.gestion_categorias, name='gestion_categorias'),
    path('admin-dashboard/categorias/agregar/', views.agregar_categoria, name='agregar_categoria'),
    
    # Productos - General
    path('admin-dashboard/productos/', views.lista_productos_general, name='lista_productos_general'),
    
    # Labiales
    path('admin-dashboard/productos/labiales/', views.listar_labiales, name='listar_labiales'),
    path('admin-dashboard/productos/labiales/agregar/', views.agregar_labial, name='agregar_labial'),
    path('admin-dashboard/productos/labiales/editar/<int:id>/', views.editar_labial, name='editar_labial'),
    path('admin-dashboard/productos/labiales/eliminar/<int:id>/', views.eliminar_labial, name='eliminar_labial'),
    
    # Bases
    path('admin-dashboard/productos/bases/', views.listar_bases, name='listar_bases'),
    path('admin-dashboard/productos/bases/agregar/', views.agregar_base, name='agregar_base'),
    path('admin-dashboard/productos/bases/editar/<int:id>/', views.editar_base, name='editar_base'),
    path('admin-dashboard/productos/bases/eliminar/<int:id>/', views.eliminar_base, name='eliminar_base'),
    
    # Rímel
    path('admin-dashboard/productos/rimel/', views.listar_rimel, name='listar_rimel'),
    path('admin-dashboard/productos/rimel/agregar/', views.agregar_rimel, name='agregar_rimel'),
    path('admin-dashboard/productos/rimel/editar/<int:id>/', views.editar_rimel, name='editar_rimel'),
    path('admin-dashboard/productos/rimel/eliminar/<int:id>/', views.eliminar_rimel, name='eliminar_rimel'),
    
    # Rubores
    path('admin-dashboard/productos/rubores/', views.listar_rubores, name='listar_rubores'),
    path('admin-dashboard/productos/rubores/agregar/', views.agregar_rubor, name='agregar_rubor'),
    path('admin-dashboard/productos/rubores/editar/<int:id>/', views.editar_rubor, name='editar_rubor'),
    path('admin-dashboard/productos/rubores/eliminar/<int:id>/', views.eliminar_rubor, name='eliminar_rubor'),
    
    # Correctores
    path('admin-dashboard/productos/correctores/', views.listar_correctores, name='listar_correctores'),
    path('admin-dashboard/productos/correctores/agregar/', views.agregar_corrector, name='agregar_corrector'),
    path('admin-dashboard/productos/correctores/editar/<int:id>/', views.editar_corrector, name='editar_corrector'),
    path('admin-dashboard/productos/correctores/eliminar/<int:id>/', views.eliminar_corrector, name='eliminar_corrector'),
    
    # Polvos
    path('admin-dashboard/productos/polvos/', views.listar_polvos, name='listar_polvos'),
    path('admin-dashboard/productos/polvos/agregar/', views.agregar_polvo, name='agregar_polvo'),
    path('admin-dashboard/productos/polvos/editar/<int:id>/', views.editar_polvo, name='editar_polvo'),
    path('admin-dashboard/productos/polvos/eliminar/<int:id>/', views.eliminar_polvo, name='eliminar_polvo'),
]