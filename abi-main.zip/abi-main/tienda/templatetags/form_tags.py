from django import template
from django.utils.html import conditional_escape
from django.utils.safestring import mark_safe

register = template.Library()


@register.filter(name='add_class')
def add_class(field, css_class):
    """Add a CSS class to a form field's widget.

    Usage in template: `{{ form.field|add_class:'form-control' }}`
    This will set or append to the widget's 'class' attribute.
    """
    try:
        # If it's a BoundField, we can use its widget attrs
        widget = field.field.widget
    except Exception:
        # If someone passed a plain widget or other object, fallback to string
        return field

    attrs = widget.attrs.copy() if hasattr(widget, 'attrs') else {}
    existing = attrs.get('class', '')
    classes = (existing + ' ' + css_class).strip() if existing else css_class
    attrs['class'] = classes

    # Render the field with the updated attrs
    try:
        return field.as_widget(attrs=attrs)
    except Exception:
        # Last resort: return original field
        return field
