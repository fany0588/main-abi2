// Funciones JavaScript para el panel de administración

$(document).ready(function() {
    // Inicializar DataTables
    if ($('#dataTable').length) {
        $('#dataTable').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.25/i18n/Spanish.json"
            },
            "responsive": true,
            "order": [[0, "desc"]]
        });
    }
    
    // Vista previa de imagen en formularios
    $('input[type="file"]').on('change', function() {
        const input = $(this);
        const previewContainer = input.closest('.form-group').find('.image-preview-container');
        const previewImg = previewContainer.find('.image-preview');
        const file = this.files[0];
        
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewImg.attr('src', e.target.result);
                previewContainer.removeClass('empty');
            };
            reader.readAsDataURL(file);
        }
    });
    
    // Confirmación para acciones destructivas
    $('.btn-danger').on('click', function(e) {
        if ($(this).hasClass('confirm-delete')) {
            if (!confirm('¿Estás seguro de que deseas realizar esta acción? Esta acción no se puede deshacer.')) {
                e.preventDefault();
                return false;
            }
        }
    });
    
    // Actualizar vista previa del producto en tiempo real
    const updateProductPreview = function() {
        const nombre = $('#id_nombre').val() || 'Nombre del Producto';
        const precio = $('#id_precio').val() ? '$' + $('#id_precio').val() : '$0.00';
        const descripcion = $('#id_descripcion').val() || 'Descripción del producto...';
        
        $('#previewNombre').text(nombre);
        $('#previewPrecio').text(precio);
        $('#previewDescripcion').text(descripcion);
    };
    
    $('#id_nombre, #id_precio, #id_descripcion').on('input', updateProductPreview);
    
    // Validación de stock
    $('#id_stock').on('change', function() {
        const stock = parseInt($(this).val());
        if (stock < 0) {
            alert('El stock no puede ser negativo');
            $(this).val(0);
        }
    });
    
    // Filtro de productos por categoría
    $('.category-filter').on('click', function(e) {
        e.preventDefault();
        const categoria = $(this).data('categoria');
        
        if (categoria === 'todos') {
            $('.product-row').show();
        } else {
            $('.product-row').hide();
            $('.product-row[data-categoria="' + categoria + '"]').show();
        }
    });
    
    // Tooltips
    $('[data-bs-toggle="tooltip"]').tooltip();
    
    // Contador de caracteres para descripciones
    $('#id_descripcion').on('input', function() {
        const length = $(this).val().length;
        const counter = $(this).closest('.form-group').find('.char-counter');
        if (counter.length) {
            counter.text(length + ' caracteres');
            
            if (length > 500) {
                counter.addClass('text-danger');
            } else {
                counter.removeClass('text-danger');
            }
        }
    });
    
    // Auto-guardado de formularios
    let autoSaveTimer;
    $('form.auto-save input, form.auto-save textarea, form.auto-save select').on('input change', function() {
        clearTimeout(autoSaveTimer);
        autoSaveTimer = setTimeout(function() {
            const form = $('form.auto-save');
            const formData = new FormData(form[0]);
            formData.append('autosave', 'true');
            
            $.ajax({
                url: form.attr('action'),
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        showNotification('Cambios guardados automáticamente', 'success');
                    }
                }
            });
        }, 2000);
    });
    
    // Mostrar notificaciones
    function showNotification(message, type = 'info') {
        const alert = $('<div class="alert alert-' + type + ' alert-dismissible fade show" role="alert">' +
                        message +
                        '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
                        '</div>');
        
        $('.alert-container').append(alert);
        
        setTimeout(function() {
            alert.alert('close');
        }, 3000);
    }
    
    // Exportar datos
    $('.export-btn').on('click', function() {
        const format = $(this).data('format');
        const table = $(this).data('table');
        
        $.ajax({
            url: '/admin/export/' + table + '/' + format + '/',
            type: 'GET',
            xhrFields: {
                responseType: 'blob'
            },
            success: function(blob) {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = table + '_export.' + format;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
            }
        });
    });
});