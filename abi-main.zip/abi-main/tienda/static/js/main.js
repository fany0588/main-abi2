// main.js - comportamientos globales del frontend
// Reveal admin button when user presses Ctrl+Alt+A (configurable)
(function(){
    document.addEventListener('keydown', function(e){
        try{
            if (e.ctrlKey && e.altKey && e.key && e.key.toLowerCase() === 'a'){
                var btn = document.getElementById('hiddenAdminBtn');
                if (!btn) return;
                // Mostrar botón (temporalmente) y centrar atención
                btn.classList.add('visible');
                btn.style.display = 'block';
                btn.focus();
                // Auto-ocultar tras 12s
                setTimeout(function(){
                    btn.classList.remove('visible');
                    btn.style.display = 'none';
                }, 12000);
            }
        }catch(err){
            console.error(err);
        }
    });
})();
