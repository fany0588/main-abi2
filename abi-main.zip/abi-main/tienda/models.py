from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone
from django.urls import reverse
import uuid

# ===== MODELOS DE PRODUCTOS =====

class CategoriaProducto(models.Model):
    """Categorías de productos de maquillaje"""
    nombre = models.CharField(max_length=100, unique=True)
    descripcion = models.TextField(blank=True)
    icono = models.CharField(max_length=50, default='fas fa-sparkles')
    color = models.CharField(max_length=20, default='#e83e8c')
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    activo = models.BooleanField(default=True)
    
    class Meta:
        verbose_name = 'Categoría'
        verbose_name_plural = 'Categorías'
        ordering = ['nombre']
    
    def __str__(self):
        return self.nombre
    
    def get_absolute_url(self):
        return reverse('productos_por_categoria', args=[self.id])
    
    @property
    def cantidad_productos(self):
        return self.productos.filter(activo=True).count()


class Producto(models.Model):
    """Productos de maquillaje"""
    
    TIPOS_PRODUCTO = [
        ('labial', 'Labial'),
        ('base', 'Base'),
        ('rimel', 'Rímel'),
        ('rubor', 'Rubor'),
        ('corrector', 'Corrector'),
        ('polvo', 'Polvo'),
        ('sombras', 'Sombras'),
        ('delineador', 'Delineador'),
        ('iluminador', 'Iluminador'),
        ('bronceador', 'Bronceador'),
        ('cejas', 'Cejas'),
        ('brochas', 'Brochas'),
        ('otros', 'Otros'),
    ]
    
    MARCA_CHOICES = [
        ('maybelline', 'Maybelline'),
        ('loreal', "L'Oréal"),
        ('mac', 'MAC'),
        ('revlon', 'Revlon'),
        ('nyx', 'NYX'),
        ('estee_lauder', 'Estée Lauder'),
        ('clinique', 'Clinique'),
        ('glow_beauty', 'Glow Beauty'),
        ('nars', 'NARS'),
        ('too_faced', 'Too Faced'),
        ('urban_decay', 'Urban Decay'),
        ('fenty', 'Fenty Beauty'),
        ('pat_mcgrath', 'Pat McGrath Labs'),
        ('charlotte_tilbury', 'Charlotte Tilbury'),
        ('huda', 'Huda Beauty'),
    ]
    
    # Información básica
    nombre = models.CharField(max_length=200)
    descripcion = models.TextField()
    tipo = models.CharField(max_length=20, choices=TIPOS_PRODUCTO)
    categoria = models.ForeignKey(CategoriaProducto, on_delete=models.CASCADE, 
                                 related_name='productos')
    marca = models.CharField(max_length=50, choices=MARCA_CHOICES)
    sku = models.CharField(max_length=50, unique=True)
    
    # Precios y stock
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    precio_original = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    stock = models.PositiveIntegerField(default=0)
    stock_minimo = models.PositiveIntegerField(default=5)
    
    # Imágenes
    imagen_principal = models.ImageField(upload_to='productos/')
    imagen_2 = models.ImageField(upload_to='productos/', blank=True, null=True)
    imagen_3 = models.ImageField(upload_to='productos/', blank=True, null=True)
    imagen_4 = models.ImageField(upload_to='productos/', blank=True, null=True)
    
    # Características
    colores_disponibles = models.JSONField(default=list, blank=True)  # Lista de colores
    tono = models.CharField(max_length=50, blank=True)
    cobertura = models.CharField(max_length=50, blank=True)  # Ligera, media, completa
    textura = models.CharField(max_length=50, blank=True)  # Mate, brillo, satinado
    duracion = models.CharField(max_length=50, blank=True)  # 8h, 12h, 24h
    ingredientes = models.TextField(blank=True)
    tipo_piel = models.CharField(max_length=100, blank=True)  # Mixta, grasa, seca, sensible
    
    # Metadata
    destacado = models.BooleanField(default=False)
    nuevo = models.BooleanField(default=True)
    en_oferta = models.BooleanField(default=False)
    activo = models.BooleanField(default=True)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    fecha_actualizacion = models.DateTimeField(auto_now=True)
    
    # SEO
    slug = models.SlugField(max_length=250, unique=True, blank=True)
    meta_descripcion = models.CharField(max_length=160, blank=True)
    
    class Meta:
        verbose_name = 'Producto'
        verbose_name_plural = 'Productos'
        ordering = ['-fecha_creacion']
        indexes = [
            models.Index(fields=['tipo']),
            models.Index(fields=['marca']),
            models.Index(fields=['precio']),
            models.Index(fields=['destacado']),
            models.Index(fields=['en_oferta']),
        ]
    
    def __str__(self):
        return f"{self.nombre} - {self.get_marca_display()}"
    
    def save(self, *args, **kwargs):
        # Generar SKU automático si no existe
        if not self.sku:
            tipo_codigo = self.tipo[:3].upper()
            marca_codigo = self.marca[:3].upper()
            self.sku = f"{tipo_codigo}-{marca_codigo}-{str(uuid.uuid4())[:8].upper()}"
        
        # Generar slug si no existe
        if not self.slug:
            from django.utils.text import slugify
            self.slug = slugify(f"{self.nombre} {self.marca}")
        
        super().save(*args, **kwargs)
    
    def get_absolute_url(self):
        return reverse('producto_detalle', args=[self.id, self.slug])
    
    @property
    def tiene_descuento(self):
        return self.precio_original and self.precio_original > self.precio
    
    @property
    def porcentaje_descuento(self):
        if self.tiene_descuento:
            return int(((self.precio_original - self.precio) / self.precio_original) * 100)
        return 0
    
    @property
    def bajo_stock(self):
        return self.stock < self.stock_minimo
    
    @property
    def agotado(self):
        return self.stock == 0
    
    @property
    def promedio_calificaciones(self):
        promedio = self.calificaciones.aggregate(models.Avg('puntuacion'))['puntuacion__avg']
        return round(promedio, 1) if promedio else 0
    
    @property
    def cantidad_calificaciones(self):
        return self.calificaciones.count()
    
    @property
    def imagenes_lista(self):
        """Devuelve lista de todas las imágenes disponibles"""
        imagenes = [self.imagen_principal]
        if self.imagen_2:
            imagenes.append(self.imagen_2)
        if self.imagen_3:
            imagenes.append(self.imagen_3)
        if self.imagen_4:
            imagenes.append(self.imagen_4)
        return imagenes


class CalificacionProducto(models.Model):
    """Calificaciones y reseñas de productos"""
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name='calificaciones')
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    puntuacion = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)]
    )
    titulo = models.CharField(max_length=100)
    comentario = models.TextField()
    ventajas = models.TextField(blank=True)  # Lo que le gustó
    desventajas = models.TextField(blank=True)  # Lo que no le gustó
    recomendado = models.BooleanField(default=True)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    fecha_actualizacion = models.DateTimeField(auto_now=True)
    verificado_compra = models.BooleanField(default=False)
    activo = models.BooleanField(default=True)
    
    class Meta:
        verbose_name = 'Calificación'
        verbose_name_plural = 'Calificaciones'
        unique_together = ['producto', 'usuario']
        ordering = ['-fecha_creacion']
    
    def __str__(self):
        return f"{self.usuario.username} - {self.producto.nombre}: {self.puntuacion}/5"


# ===== MODELOS DE USUARIO =====

class PerfilUsuario(models.Model):
    """Perfil extendido para usuarios"""
    usuario = models.OneToOneField(User, on_delete=models.CASCADE, related_name='perfil')
    
    # Información personal
    avatar = models.ImageField(upload_to='avatares/', blank=True, null=True)
    telefono = models.CharField(max_length=20, blank=True)
    fecha_nacimiento = models.DateField(null=True, blank=True)
    genero = models.CharField(max_length=20, blank=True, choices=[
        ('femenino', 'Femenino'),
        ('masculino', 'Masculino'),
        ('otro', 'Otro'),
        ('prefiero_no_decir', 'Prefiero no decir'),
    ])
    
    # Dirección
    direccion = models.TextField(blank=True)
    ciudad = models.CharField(max_length=100, blank=True)
    codigo_postal = models.CharField(max_length=20, blank=True)
    pais = models.CharField(max_length=50, blank=True, default='México')
    
    # Preferencias
    tipo_piel = models.CharField(max_length=50, blank=True)
    tono_piel = models.CharField(max_length=50, blank=True)
    preferencias_maquillaje = models.JSONField(default=list, blank=True)
    
    # Configuración de notificaciones
    recibe_newsletter = models.BooleanField(default=True)
    recibe_ofertas = models.BooleanField(default=True)
    recibe_notificaciones = models.BooleanField(default=True)
    
    # Datos de membresía
    puntos_fidelidad = models.PositiveIntegerField(default=0)
    nivel_membresia = models.CharField(max_length=20, default='basico', choices=[
        ('basico', 'Básico'),
        ('premium', 'Premium'),
        ('vip', 'VIP'),
    ])
    fecha_registro = models.DateTimeField(auto_now_add=True)
    ultima_visita = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Perfil de Usuario'
        verbose_name_plural = 'Perfiles de Usuario'
    
    def __str__(self):
        return f"Perfil de {self.usuario.username}"
    
    @property
    def nombre_completo(self):
        return f"{self.usuario.first_name} {self.usuario.last_name}".strip() or self.usuario.username
    
    @property
    def es_premium(self):
        return self.nivel_membresia in ['premium', 'vip']


# ===== MODELOS DE CARRITO Y PEDIDOS =====

class Carrito(models.Model):
    """Carrito de compras de un usuario"""
    usuario = models.OneToOneField(User, on_delete=models.CASCADE, related_name='carrito')
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    fecha_actualizacion = models.DateTimeField(auto_now=True)
    activo = models.BooleanField(default=True)
    
    class Meta:
        verbose_name = 'Carrito'
        verbose_name_plural = 'Carritos'
    
    def __str__(self):
        return f"Carrito de {self.usuario.username}"
    
    @property
    def total_items(self):
        return sum(item.cantidad for item in self.items.all())
    
    @property
    def subtotal(self):
        return sum(item.subtotal for item in self.items.all())
    
    @property
    def total(self):
        return self.subtotal  # Por ahora sin impuestos/envíos
    
    def agregar_producto(self, producto, cantidad=1):
        """Agrega un producto al carrito"""
        item, created = ItemCarrito.objects.get_or_create(
            carrito=self,
            producto=producto,
            defaults={'cantidad': cantidad}
        )
        if not created:
            item.cantidad += cantidad
            item.save()
        return item
    
    def vaciar(self):
        """Vacía el carrito"""
        self.items.all().delete()


class ItemCarrito(models.Model):
    """Ítems individuales en el carrito"""
    carrito = models.ForeignKey(Carrito, on_delete=models.CASCADE, related_name='items')
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)
    fecha_agregado = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Ítem de Carrito'
        verbose_name_plural = 'Ítems de Carrito'
        unique_together = ['carrito', 'producto']
    
    def __str__(self):
        return f"{self.cantidad} x {self.producto.nombre}"
    
    @property
    def subtotal(self):
        return self.producto.precio * self.cantidad
    
    @property
    def disponible(self):
        return self.cantidad <= self.producto.stock


class Pedido(models.Model):
    """Pedidos realizados por los usuarios"""
    
    ESTADOS_PEDIDO = [
        ('pendiente', 'Pendiente'),
        ('confirmado', 'Confirmado'),
        ('procesando', 'Procesando'),
        ('enviado', 'Enviado'),
        ('entregado', 'Entregado'),
        ('cancelado', 'Cancelado'),
        ('reembolsado', 'Reembolsado'),
    ]
    
    METODOS_PAGO = [
        ('tarjeta', 'Tarjeta de Crédito/Débito'),
        ('paypal', 'PayPal'),
        ('transferencia', 'Transferencia Bancaria'),
        ('efectivo', 'Efectivo al recibir'),
        ('oxxo', 'Pago en OXXO'),
    ]
    
    # Información del pedido
    numero_pedido = models.CharField(max_length=20, unique=True)
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, related_name='pedidos')
    estado = models.CharField(max_length=20, choices=ESTADOS_PEDIDO, default='pendiente')
    
    # Información de envío
    direccion_envio = models.TextField()
    ciudad_envio = models.CharField(max_length=100)
    codigo_postal_envio = models.CharField(max_length=20)
    telefono_envio = models.CharField(max_length=20)
    instrucciones_especiales = models.TextField(blank=True)
    
    # Información de pago
    metodo_pago = models.CharField(max_length=20, choices=METODOS_PAGO)
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)
    costo_envio = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    descuento = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=10, decimal_places=2)
    pagado = models.BooleanField(default=False)
    fecha_pago = models.DateTimeField(null=True, blank=True)
    
    # Seguimiento
    numero_seguimiento = models.CharField(max_length=50, blank=True)
    empresa_envio = models.CharField(max_length=100, blank=True)
    fecha_envio_estimada = models.DateField(null=True, blank=True)
    fecha_envio_real = models.DateField(null=True, blank=True)
    
    # Timestamps
    fecha_pedido = models.DateTimeField(auto_now_add=True)
    fecha_actualizacion = models.DateTimeField(auto_now=True)
    fecha_cancelacion = models.DateTimeField(null=True, blank=True)
    
    # Metadata
    notas_internas = models.TextField(blank=True)
    codigo_descuento = models.CharField(max_length=50, blank=True)
    
    class Meta:
        verbose_name = 'Pedido'
        verbose_name_plural = 'Pedidos'
        ordering = ['-fecha_pedido']
        indexes = [
            models.Index(fields=['numero_pedido']),
            models.Index(fields=['estado']),
            models.Index(fields=['usuario', 'fecha_pedido']),
        ]
    
    def __str__(self):
        return f"Pedido #{self.numero_pedido} - {self.usuario.username}"
    
    def save(self, *args, **kwargs):
        if not self.numero_pedido:
            fecha_actual = timezone.now()
            self.numero_pedido = f"ORD-{fecha_actual.strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"
        super().save(*args, **kwargs)
    
    @property
    def puede_cancelar(self):
        return self.estado in ['pendiente', 'confirmado']
    
    @property
    def tiempo_transcurrido(self):
        return (timezone.now() - self.fecha_pedido).days
    
    @property
    def color_estado(self):
        colores = {
            'pendiente': 'warning',
            'confirmado': 'info',
            'procesando': 'primary',
            'enviado': 'success',
            'entregado': 'success',
            'cancelado': 'danger',
            'reembolsado': 'secondary',
        }
        return colores.get(self.estado, 'secondary')


class ItemPedido(models.Model):
    """Ítems individuales en un pedido"""
    pedido = models.ForeignKey(Pedido, on_delete=models.CASCADE, related_name='items')
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField()
    precio_unitario = models.DecimalField(max_digits=10, decimal_places=2)
    
    class Meta:
        verbose_name = 'Ítem de Pedido'
        verbose_name_plural = 'Ítems de Pedido'
    
    def __str__(self):
        return f"{self.cantidad} x {self.producto.nombre}"
    
    @property
    def subtotal(self):
        return self.precio_unitario * self.cantidad


# ===== MODELOS DE FAVORITOS Y LISTAS =====

class Favorito(models.Model):
    """Productos favoritos de los usuarios"""
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, related_name='favoritos')
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    fecha_agregado = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Favorito'
        verbose_name_plural = 'Favoritos'
        unique_together = ['usuario', 'producto']
    
    def __str__(self):
        return f"{self.usuario.username} - {self.producto.nombre}"


class ListaDeseos(models.Model):
    """Listas de deseos personalizadas"""
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, related_name='listas_deseos')
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField(blank=True)
    publica = models.BooleanField(default=False)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    fecha_actualizacion = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Lista de Deseos'
        verbose_name_plural = 'Listas de Deseos'
        unique_together = ['usuario', 'nombre']
    
    def __str__(self):
        return f"{self.nombre} - {self.usuario.username}"


class ItemListaDeseos(models.Model):
    """Ítems en listas de deseos"""
    lista = models.ForeignKey(ListaDeseos, on_delete=models.CASCADE, related_name='items')
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    fecha_agregado = models.DateTimeField(auto_now_add=True)
    prioridad = models.PositiveIntegerField(default=1, choices=[
        (1, 'Baja'),
        (2, 'Media'),
        (3, 'Alta'),
    ])
    
    class Meta:
        verbose_name = 'Ítem de Lista de Deseos'
        verbose_name_plural = 'Ítems de Listas de Deseos'
        unique_together = ['lista', 'producto']
    
    def __str__(self):
        return f"{self.producto.nombre} en {self.lista.nombre}"


# ===== MODELOS DE CUPONES Y DESCUENTOS =====

class CuponDescuento(models.Model):
    """Cupones de descuento"""
    codigo = models.CharField(max_length=50, unique=True)
    descripcion = models.TextField(blank=True)
    tipo_descuento = models.CharField(max_length=20, choices=[
        ('porcentaje', 'Porcentaje'),
        ('monto_fijo', 'Monto Fijo'),
    ])
    valor = models.DecimalField(max_digits=10, decimal_places=2)
    monto_minimo = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    max_usos = models.PositiveIntegerField(null=True, blank=True)
    usos_actuales = models.PositiveIntegerField(default=0)
    fecha_inicio = models.DateTimeField()
    fecha_fin = models.DateTimeField()
    activo = models.BooleanField(default=True)
    productos_aplicables = models.ManyToManyField(Producto, blank=True)
    categorias_aplicables = models.ManyToManyField(CategoriaProducto, blank=True)
    solo_nuevos_usuarios = models.BooleanField(default=False)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Cupón de Descuento'
        verbose_name_plural = 'Cupones de Descuento'
    
    def __str__(self):
        return self.codigo
    
    @property
    def valido(self):
        ahora = timezone.now()
        return (
            self.activo and
            self.fecha_inicio <= ahora <= self.fecha_fin and
            (self.max_usos is None or self.usos_actuales < self.max_usos)
        )
    
    def aplicar_descuento(self, monto):
        """Aplica el descuento al monto dado"""
        if self.tipo_descuento == 'porcentaje':
            return monto * (self.valor / 100)
        else:  # monto_fijo
            return min(self.valor, monto)
    
    def incrementar_uso(self):
        """Incrementa el contador de usos"""
        self.usos_actuales += 1
        self.save()


class UsoCupon(models.Model):
    """Registro de usos de cupones"""
    cupon = models.ForeignKey(CuponDescuento, on_delete=models.CASCADE, related_name='usos')
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, related_name='cupones_usados')
    pedido = models.ForeignKey(Pedido, on_delete=models.CASCADE, related_name='cupones_aplicados')
    descuento_aplicado = models.DecimalField(max_digits=10, decimal_places=2)
    fecha_uso = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Uso de Cupón'
        verbose_name_plural = 'Usos de Cupones'
        unique_together = ['cupon', 'pedido']
    
    def __str__(self):
        return f"{self.cupon.codigo} - {self.usuario.username}"


# ===== MODELOS DE BLOG Y CONTENIDO =====

class BlogCategoria(models.Model):
    """Categorías del blog"""
    nombre = models.CharField(max_length=100)
    slug = models.SlugField(max_length=100, unique=True)
    descripcion = models.TextField(blank=True)
    imagen = models.ImageField(upload_to='blog/categorias/', blank=True, null=True)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Categoría del Blog'
        verbose_name_plural = 'Categorías del Blog'
    
    def __str__(self):
        return self.nombre


class ArticuloBlog(models.Model):
    """Artículos del blog"""
    titulo = models.CharField(max_length=200)
    slug = models.SlugField(max_length=250, unique=True)
    contenido = models.TextField()
    resumen = models.TextField(max_length=500)
    autor = models.ForeignKey(User, on_delete=models.CASCADE, related_name='articulos_blog')
    categoria = models.ForeignKey(BlogCategoria, on_delete=models.SET_NULL, 
                                 null=True, related_name='articulos')
    imagen_portada = models.ImageField(upload_to='blog/articulos/')
    etiquetas = models.CharField(max_length=200, blank=True)
    publicado = models.BooleanField(default=False)
    fecha_publicacion = models.DateTimeField(null=True, blank=True)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    fecha_actualizacion = models.DateTimeField(auto_now=True)
    vistas = models.PositiveIntegerField(default=0)
    
    class Meta:
        verbose_name = 'Artículo del Blog'
        verbose_name_plural = 'Artículos del Blog'
        ordering = ['-fecha_publicacion']
    
    def __str__(self):
        return self.titulo
    
    def incrementar_vistas(self):
        self.vistas += 1
        self.save(update_fields=['vistas'])


class ComentarioBlog(models.Model):
    """Comentarios en artículos del blog"""
    articulo = models.ForeignKey(ArticuloBlog, on_delete=models.CASCADE, related_name='comentarios')
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comentarios_blog')
    contenido = models.TextField()
    padre = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, 
                             related_name='respuestas')
    aprobado = models.BooleanField(default=False)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Comentario del Blog'
        verbose_name_plural = 'Comentarios del Blog'
        ordering = ['fecha_creacion']
    
    def __str__(self):
        return f"Comentario de {self.usuario.username} en {self.articulo.titulo[:50]}"


# ===== MODELOS DE SEGUIMIENTO Y ANALÍTICAS =====

class VisitaProducto(models.Model):
    """Registro de visitas a productos"""
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name='visitas')
    usuario = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    direccion_ip = models.GenericIPAddressField()
    user_agent = models.TextField(blank=True)
    fecha_visita = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Visita de Producto'
        verbose_name_plural = 'Visitas de Productos'
        indexes = [
            models.Index(fields=['producto', 'fecha_visita']),
            models.Index(fields=['usuario', 'fecha_visita']),
        ]
    
    def __str__(self):
        return f"Visita a {self.producto.nombre}"


class BusquedaUsuario(models.Model):
    """Registro de búsquedas realizadas por usuarios"""
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    query = models.CharField(max_length=255)
    resultados = models.PositiveIntegerField(default=0)
    fecha_busqueda = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Búsqueda de Usuario'
        verbose_name_plural = 'Búsquedas de Usuarios'
        indexes = [
            models.Index(fields=['usuario', 'fecha_busqueda']),
            models.Index(fields=['query']),
        ]
    
    def __str__(self):
        return f"{self.query} - {self.usuario.username if self.usuario else 'Anónimo'}"


# ===== SEÑALES (SIGNALS) PARA MODELOS =====

from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver

@receiver(post_save, sender=User)
def crear_carrito_usuario(sender, instance, created, **kwargs):
    """Crea un carrito automáticamente cuando se crea un usuario"""
    if created:
        Carrito.objects.create(usuario=instance)
        PerfilUsuario.objects.create(usuario=instance)

@receiver(post_save, sender=User)
def guardar_carrito_usuario(sender, instance, **kwargs):
    """Guarda el carrito del usuario"""
    instance.carrito.save()

@receiver(post_save, sender=Pedido)
def actualizar_stock_pedido(sender, instance, created, **kwargs):
    """Actualiza el stock cuando se crea o cancela un pedido"""
    if created:
        # Reducir stock al crear el pedido
        for item in instance.items.all():
            producto = item.producto
            producto.stock -= item.cantidad
            producto.save()
    elif instance.estado == 'cancelado':
        # Restaurar stock al cancelar el pedido
        for item in instance.items.all():
            producto = item.producto
            producto.stock += item.cantidad
            producto.save()

@receiver(post_delete, sender=ItemCarrito)
@receiver(post_save, sender=ItemCarrito)
def actualizar_carrito(sender, instance, **kwargs):
    """Actualiza la fecha de modificación del carrito"""
    try:
        instance.carrito.fecha_actualizacion = timezone.now()
        instance.carrito.save()
    except Carrito.DoesNotExist:
        pass