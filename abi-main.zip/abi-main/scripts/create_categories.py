import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'makeup_store.settings')
django.setup()

from tienda.models import CategoriaProducto

cats = [
    ('Bases', 'Productos de base para todo tipo de piel', 'fas fa-paint-roller', '#f8d7c4'),
    ('Rimel', 'Rimel y productos para pestañas', 'fas fa-eye', '#6c757d'),
    ('Rubores', 'Rubores y coloretes', 'fas fa-circle', '#ff6b8b'),
    ('Correctores', 'Correctores e iluminadores', 'fas fa-concierge-bell', '#ffc107'),
    ('Polvos', 'Polvos y fijadores de maquillaje', 'fas fa-snowflake', '#9b59b6'),
]

for nombre, descripcion, icono, color in cats:
    c, created = CategoriaProducto.objects.get_or_create(
        nombre=nombre,
        defaults={
            'descripcion': descripcion,
            'icono': icono,
            'color': color,
            'activo': True,
        }
    )
    print(nombre, 'created' if created else 'exists', c.id)

print('\nALL CATEGORIES:')
for c in CategoriaProducto.objects.values('id','nombre','activo'):
    print(c)
